import { useEffect, useRef, useState } from 'react';
import { restoreStarterContent } from '../data/seed.js';
import { exportBackup, importBackup, shareOrDownloadJson, type BackupFile } from '../lib/backup.js';
import { suggestDailyKcal } from '../lib/calories.js';
import { deleteBlob, deleteDatabase, put, remove, saveBlob } from '../lib/db.js';
import { usePrefs, useProfile } from '../lib/hooks.js';
import { uid } from '../lib/ids.js';
import { useT } from '../lib/i18n.js';
import { canPromptInstall, isInstalled, promptInstall, subscribeInstall } from '../lib/install-prompt.js';
import { checkForUpdate, reinstallAppFiles } from '../lib/updates.js';
import type { Lang, Theme } from '../lib/models.js';
import { useMusicTracks } from '../lib/queries.js';
import { Button, Field, NumberInput, Row, Screen, Segmented, Select, TextInput, Toggle, TopBar } from '../ui/components.js';
import { confirmDialog, toast } from '../ui/dialogs.js';
import { IconDownload, IconMusic, IconRepeat, IconTrash, IconUpload } from '../ui/icons.js';

const MAX_TRACK_BYTES = 25 * 1024 * 1024; // 25MB - generous for a full song at typical mp3 bitrates

const IS_STANDALONE = (() => { try { return matchMedia('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone === true; } catch { return false; } })();
const IS_IOS = /iPhone|iPad|iPod/.test(navigator.userAgent);
const IS_ANDROID = /Android/.test(navigator.userAgent);

export function SettingsScreen() {
  const t = useT();
  const [profile, setProfile] = useProfile();
  const [prefs, setPrefs] = usePrefs();
  const fileRef = useRef<HTMLInputElement | null>(null);
  const musicFileRef = useRef<HTMLInputElement | null>(null);
  const [busy, setBusy] = useState(false);
  const [musicBusy, setMusicBusy] = useState(false);
  const musicTracks = useMusicTracks();
  const [canInstall, setCanInstall] = useState(canPromptInstall());
  const [installed, setInstalled] = useState(isInstalled());
  useEffect(() => subscribeInstall(() => { setCanInstall(canPromptInstall()); setInstalled(isInstalled()); }), []);

  const addMusicTracks = async (files: FileList) => {
    setMusicBusy(true);
    try {
      let skipped = 0;
      for (const file of Array.from(files)) {
        if (file.size > MAX_TRACK_BYTES) { skipped++; continue; }
        const blobId = await saveBlob(file, file.name);
        await put('musicTracks', { id: uid('mtr'), name: file.name.replace(/\.[^.]+$/, ''), blobId, addedAt: Date.now() });
      }
      if (skipped > 0) toast(t('settings.musicTrackTooBig', { n: skipped }));
    } finally { setMusicBusy(false); }
  };

  const removeMusicTrack = async (track: { id: string; name: string; blobId: string }) => {
    const ok = await confirmDialog({ title: t('settings.removeTrackTitle', { name: track.name }), confirmLabel: t('common.remove'), danger: true });
    if (!ok) return;
    await deleteBlob(track.blobId);
    await remove('musicTracks', track.id);
  };

  const doInstall = async () => {
    const outcome = await promptInstall();
    if (outcome === 'accepted') toast(t('settings.appInstalled'));
  };

  const suggest = (goal: 'lose' | 'maintain' | 'gain') => {
    const kcal = suggestDailyKcal(profile.weightKg, profile.heightCm, profile.age, profile.sex, goal);
    const protein = Math.round(profile.weightKg * 1.8);
    const fat = Math.round((kcal * 0.27) / 9);
    const carbs = Math.max(0, Math.round((kcal - protein * 4 - fat * 9) / 4));
    setProfile({ targetKcal: kcal, targetProtein: protein, targetFat: fat, targetCarbs: carbs });
    const goalText = goal === 'lose' ? t('settings.goal.lose') : goal === 'gain' ? t('settings.goal.gain') : t('settings.goal.maintain');
    toast(t('settings.targetsSetFor', { goal: goalText }));
  };

  const doExport = async () => {
    setBusy(true);
    try {
      const data = await exportBackup();
      const name = `forma-backup-${new Date().toISOString().slice(0, 10)}.json`;
      const how = await shareOrDownloadJson(name, data);
      toast(how === 'shared' ? t('settings.backupReady') : t('settings.backupDownloaded'));
    } catch (e) { toast(t('settings.backupFailed')); console.error(e); } finally { setBusy(false); }
  };

  const doImport = async (file: File) => {
    setBusy(true);
    try {
      const parsed = JSON.parse(await file.text()) as BackupFile;
      const counts = Object.entries(parsed.tables ?? {}).map(([k, v]) => `${(v as unknown[]).length} ${k}`).join(', ');
      const replace = await confirmDialog({ title: t('settings.restoreBackupTitle'), message: t('settings.restoreBackupMsg', { counts }), confirmLabel: t('settings.replaceAll'), cancelLabel: t('common.merge'), danger: true });
      await importBackup(parsed, replace ? 'replace' : 'merge');
      toast(replace ? t('settings.backupRestored') : t('settings.backupMerged'));
    } catch (e) { toast(t('settings.couldNotReadFile')); console.error(e); } finally { setBusy(false); if (fileRef.current) fileRef.current.value = ''; }
  };

  const [updating, setUpdating] = useState(false);
  const doUpdate = async () => {
    setUpdating(true);
    try {
      const r = await checkForUpdate();
      if (r === 'none') toast(t('settings.upToDate'));
      else if (r === 'unsupported') toast(t('settings.updateUnsupported'));
      // 'updated' → the new worker takes over and the page reloads on its own
    } finally { setUpdating(false); }
  };
  const doReinstall = async () => {
    const ok = await confirmDialog({ title: t('settings.reinstallTitle'), message: t('settings.reinstallMsg'), confirmLabel: t('settings.reinstall') });
    if (!ok) return;
    await reinstallAppFiles();
  };

  const reset = async () => {
    const ok = await confirmDialog({ title: t('settings.eraseTitle'), message: t('settings.eraseMsg'), confirmLabel: t('common.erase'), danger: true });
    if (!ok) return;
    await deleteDatabase();
    try { localStorage.clear(); } catch { /* ignore */ }
    location.reload();
  };

  return (
    <Screen>
      <TopBar large backTo="/" title={t('settings.title')} eyebrow={t('settings.home')} />
      <div className="settings-group">
        <div className="section-label">{t('settings.home')}</div>
        <div className="list">
          <div className="settings-row"><div className="l">{t('home.yourName')}<small>{t('home.yourNameHint')}</small></div><TextInput value={profile.name ?? ''} onChange={(v) => setProfile({ name: v })} placeholder="Roma" className="input-short" /></div>
        </div>
      </div>

      <div className="settings-group">
        <div className="section-label">{t('settings.profile')}</div>
        <div className="list" style={{ padding: '4px 16px 0' }}>
          <Field label={t('settings.weight')} inline hint={t('settings.weightHint')}><NumberInput value={profile.weightKg} min={30} max={300} suffix="kg" onChange={(v) => setProfile({ weightKg: v })} /></Field>
          <Field label={t('settings.height')} inline><NumberInput value={profile.heightCm} min={100} max={250} suffix="cm" onChange={(v) => setProfile({ heightCm: v })} /></Field>
          <Field label={t('settings.age')} inline><NumberInput value={profile.age} min={10} max={100} onChange={(v) => setProfile({ age: v })} /></Field>
          <Field label={t('settings.sex')} inline><Select value={profile.sex} onChange={(v) => setProfile({ sex: v })} options={[{ value: 'male', label: t('settings.male') }, { value: 'female', label: t('settings.female') }]} /></Field>
          <Field label={t('settings.weekStartsOn')} inline><Select value={String(profile.weekStartsOn) as '0' | '1'} onChange={(v) => setProfile({ weekStartsOn: Number(v) as 0 | 1 })} options={[{ value: '1', label: t('settings.monday') }, { value: '0', label: t('settings.sunday') }]} /></Field>
        </div>
      </div>

      <div className="settings-group">
        <div className="section-label">{t('settings.dailyTargets')}</div>
        <div className="list" style={{ padding: '4px 16px 0' }}>
          <Field label={t('settings.calories')} inline><NumberInput value={profile.targetKcal} min={800} max={6000} step={10} suffix="kcal" onChange={(v) => setProfile({ targetKcal: v })} /></Field>
          <Field label={t('settings.protein')} inline><NumberInput value={profile.targetProtein} min={0} max={500} suffix="g" onChange={(v) => setProfile({ targetProtein: v })} /></Field>
          <Field label={t('settings.carbs')} inline><NumberInput value={profile.targetCarbs} min={0} max={800} suffix="g" onChange={(v) => setProfile({ targetCarbs: v })} /></Field>
          <Field label={t('settings.fat')} inline><NumberInput value={profile.targetFat} min={0} max={300} suffix="g" onChange={(v) => setProfile({ targetFat: v })} /></Field>
        </div>
        <div className="small muted mt mb">{t('settings.suggestHint')}</div>
        <div className="hstack wrap">
          <Button size="sm" variant="secondary" onClick={() => suggest('lose')}>{t('settings.loseWeight')}</Button>
          <Button size="sm" variant="secondary" onClick={() => suggest('maintain')}>{t('settings.maintain')}</Button>
          <Button size="sm" variant="secondary" onClick={() => suggest('gain')}>{t('settings.gainMuscle')}</Button>
        </div>
      </div>

      <div className="settings-group">
        <div className="section-label">{t('settings.appearance')}</div>
        <div className="theme-picker">
          {(['system', 'light', 'dark'] as Theme[]).map((th) => (
            <button key={th} className={`theme-option ${prefs.theme === th ? 'active' : ''}`} onClick={() => setPrefs({ theme: th })}>
              <div className="theme-swatch" style={{ background: th === 'light' ? '#F7F5F1' : th === 'dark' ? '#0B0B0C' : 'linear-gradient(90deg, #F7F5F1 50%, #0B0B0C 50%)' }} />
              {th === 'system' ? t('settings.automatic') : th === 'light' ? t('settings.light') : t('settings.dark')}
            </button>
          ))}
        </div>
      </div>

      <div className="settings-group">
        <div className="section-label">{t('settings.language')}</div>
        <Segmented value={prefs.language} onChange={(v: Lang) => setPrefs({ language: v })} options={[{ value: 'en', label: 'English' }, { value: 'ka', label: 'ქართული' }]} />
      </div>

      <div className="settings-group">
        <div className="section-label">{t('settings.player')}</div>
        <div className="list">
          <div className="settings-row"><span className="l">{t('settings.sounds')}<small>{t('settings.soundsHint')}</small></span><Toggle checked={prefs.sound} onChange={(v) => setPrefs({ sound: v })} /></div>
          <div className="settings-row"><span className="l">{t('settings.voiceCues')}<small>{t('settings.voiceCuesHint')}</small></span><Toggle checked={prefs.voice} onChange={(v) => setPrefs({ voice: v })} /></div>
          <div className="settings-row"><span className="l">{t('settings.music')}<small>{t('settings.musicHint')}</small></span><Toggle checked={prefs.music} onChange={(v) => setPrefs({ music: v })} /></div>
          <div className="settings-row"><span className="l">{t('settings.keepAwake')}<small>{t('settings.keepAwakeHint')}</small></span><Toggle checked={prefs.keepAwake} onChange={(v) => setPrefs({ keepAwake: v })} /></div>
          <div className="settings-row"><span className="l">{t('settings.countdownCue')}</span><Segmented value={String(prefs.countdownSeconds) as '3' | '5' | '10'} onChange={(v) => setPrefs({ countdownSeconds: Number(v) })} options={[{ value: '3', label: '3 s' }, { value: '5', label: '5 s' }, { value: '10', label: '10 s' }]} /></div>
        </div>
      </div>

      <div className="settings-group">
        <div className="section-label">{t('settings.yourMusic')}</div>
        <div className="small muted mb">{t('settings.yourMusicHint')}</div>
        {musicTracks && musicTracks.length > 0 && (
          <div className="list mb">
            {musicTracks.map((tr) => (
              <Row key={tr.id} right={<Button variant="ghost" size="sm" icon={<IconTrash size={16} />} onClick={() => removeMusicTrack(tr)} />}>
                <div className="thumb"><IconMusic size={18} /></div>
                <div className="row-main"><div className="row-title">{tr.name}</div></div>
              </Row>
            ))}
          </div>
        )}
        <Button variant="secondary" full icon={<IconUpload size={18} />} disabled={musicBusy} onClick={() => musicFileRef.current?.click()}>{musicBusy ? t('common.uploading') : t('settings.addMusicTrack')}</Button>
        <input ref={musicFileRef} type="file" accept="audio/*,.mp3" multiple hidden onChange={(e: { target: HTMLInputElement }) => { const files = e.target.files; if (files && files.length) addMusicTracks(files); e.target.value = ''; }} />
      </div>

      <div className="settings-group">
        <div className="section-label">{t('settings.backup')}</div>
        <div className="small muted mb">{t('settings.backupHint')}</div>
        <div className="small muted mb">{t('settings.backupIncludes')}</div>
        <div className="stack">
          <Button variant="secondary" full icon={<IconDownload size={18} />} disabled={busy} onClick={doExport}>{t('settings.exportBackup')}</Button>
          <Button variant="secondary" full icon={<IconUpload size={18} />} disabled={busy} onClick={() => fileRef.current?.click()}>{t('settings.restoreFromBackup')}</Button>
          <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e: { target: HTMLInputElement }) => { const f = e.target.files?.[0]; if (f) doImport(f); }} />
          <Button variant="ghost" full onClick={async () => { await restoreStarterContent(); toast(t('settings.starterRestored')); }}>{t('settings.readdStarter')}</Button>
          <Button variant="danger" full onClick={reset}>{t('settings.eraseAllData')}</Button>
        </div>
      </div>

      <div className="settings-group">
        <div className="section-label">{t('settings.app')}</div>
        <div className="small muted mb">{t('settings.updateHint')}</div>
        <div className="stack">
          <Button variant="secondary" full icon={<IconRepeat size={18} />} disabled={updating} onClick={doUpdate}>{updating ? t('settings.updating') : t('settings.updateApp')}</Button>
          <Button variant="ghost" full onClick={doReinstall}>{t('settings.reinstall')}</Button>
        </div>
      </div>

      {!IS_STANDALONE && !installed && (
        <div className="settings-group">
          <div className="section-label">{t('settings.install')}</div>
          <div className="install-hint">
            {canInstall ? (
              <>
                <span>{t('settings.installPromptBody')}</span>
                <Button icon={<IconDownload size={18} />} onClick={doInstall}>{t('settings.installAppButton')}</Button>
              </>
            ) : IS_IOS ? (
              <>
                <span><b>{t('settings.installIosTitle')}</b> {t('settings.installIosBody')}</span>
                <span>{t('settings.installIosStep1', { share: t('settings.share') })}</span>
                <span>{t('settings.installIosStep2', { addHome: t('settings.addToHomeScreen'), add: t('settings.add') })}</span>
                <span className="muted">{t('settings.installIosNote')}</span>
              </>
            ) : IS_ANDROID ? (
              <>
                <span><b>{t('settings.installAndroidTitle')}</b> {t('settings.installAndroidBody')}</span>
                <span>{t('settings.installAndroidStep1')}</span>
                <span>{t('settings.installAndroidStep2')}</span>
                <span className="muted">{t('settings.installAndroidNote')}</span>
              </>
            ) : (
              <span>{t('settings.installDesktop')}</span>
            )}
          </div>
        </div>
      )}

      <div className="small muted" style={{ textAlign: 'center', marginTop: 24 }}>{t('common.appTagline')}</div>
    </Screen>
  );
}
