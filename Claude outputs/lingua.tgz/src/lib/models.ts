// Domain model. Everything is stored in IndexedDB (see db.ts) and exported as JSON for backups.

export type ExerciseKind = 'time' | 'reps';

export type Demo =
  | { type: 'builtin'; key: string }
  | { type: 'blob'; blobId: string }
  | { type: 'video'; file: string }
  | { type: 'none' };

export interface Exercise {
  id: string;
  name: string;
  muscles: string[];
  equipment: string[];
  kind: ExerciseKind;
  /** Metabolic equivalent of task; kcal/h ≈ MET × kg. */
  met: number;
  /** Seconds per rep, used to estimate time (and kcal) of rep-based blocks. */
  secPerRep: number;
  /** Default duration (time) or reps (reps) suggested in the builder. */
  defaultAmount: number;
  demo: Demo;
  cues: string[];
  isCustom: boolean;
  createdAt: number;
  updatedAt: number;
}

export type Block =
  | { id: string; type: 'exercise'; exerciseId: string; seconds?: number; reps?: number }
  | { id: string; type: 'rest'; seconds: number }
  | { id: string; type: 'group'; name?: string; rounds: number; restBetweenRounds: number; blocks: Block[] };

export interface Workout {
  id: string;
  name: string;
  description: string;
  blocks: Block[];
  color: string;
  createdAt: number;
  updatedAt: number;
}

/** A flat, fully-expanded step of a workout (groups unrolled). */
export interface Step {
  index: number;
  type: 'exercise' | 'rest';
  label: string;
  seconds: number;
  reps?: number;
  exerciseId?: string;
  met: number;
  round?: { n: number; of: number; name?: string };
}

export interface Session {
  id: string;
  workoutId: string;
  workoutName: string;
  startedAt: number;
  endedAt: number;
  kcal: number;
  completedSteps: number;
  totalSteps: number;
  activeSeconds: number;
}

export type MealCategory = 'breakfast' | 'lunch' | 'dinner' | 'snack';
export const MEAL_CATEGORIES: MealCategory[] = ['breakfast', 'lunch', 'dinner', 'snack'];

export interface Nutrition { kcal: number; protein: number; carbs: number; fat: number }

export interface Ingredient extends Nutrition {
  id: string;
  name: string;
  amount: number;
  unit: string; // g, ml, pcs, tbsp, tsp, cup…
}

export interface Dish {
  id: string;
  name: string;
  category: MealCategory;
  servings: number;
  prepMin: number;
  cookMin: number;
  tags: string[];
  ingredients: Ingredient[];
  steps: string[];
  notes: string;
  imageBlobId?: string;
  /** If set, replaces the computed per-serving nutrition. */
  nutritionOverride?: Nutrition;
  favorite: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface MealSlot {
  id: string;
  date: string; // YYYY-MM-DD
  slot: MealCategory;
  dishId: string;
  servings: number;
  eaten: boolean;
  order: number;
}

export interface ScheduleEntry {
  weekday: number; // 0 = Sunday … 6 = Saturday
  workoutId: string;
}

export interface StoredBlob { id: string; blob: Blob; type: string; name: string }

/** A user-uploaded audio file to play as background music during workouts (metadata only - the file itself lives in `blobs`). */
export interface MusicTrack { id: string; name: string; blobId: string; addedAt: number }

export type Theme = 'system' | 'light' | 'dark';
export type Lang = 'en' | 'ka';

export interface Profile {
  /** Shown in the launcher greeting. */
  name: string;
  weightKg: number;
  heightCm: number;
  age: number;
  sex: 'male' | 'female';
  targetKcal: number;
  targetProtein: number;
  targetCarbs: number;
  targetFat: number;
  weekStartsOn: 0 | 1;
}

export interface Prefs {
  theme: Theme;
  sound: boolean;
  voice: boolean;
  music: boolean; // background motivational music during workouts
  countdownSeconds: number; // "3-2-1" cue length
  keepAwake: boolean;
  language: Lang;
}

/** Georgian for Georgian-locale devices, English otherwise. */
function detectLanguage(): Lang {
  try {
    const langs = (typeof navigator !== 'undefined' && (navigator.languages?.length ? navigator.languages : [navigator.language])) || [];
    if (langs.some((l) => l?.toLowerCase().startsWith('ka'))) return 'ka';
  } catch { /* ignore */ }
  return 'en';
}

export const DEFAULT_PROFILE: Profile = {
  name: '',
  weightKg: 90,
  heightCm: 178,
  age: 30,
  sex: 'male',
  targetKcal: 2100,
  targetProtein: 165,
  targetCarbs: 200,
  targetFat: 62,
  weekStartsOn: 1,
};

export const DEFAULT_PREFS: Prefs = {
  theme: 'system',
  sound: true,
  voice: true,
  music: true,
  countdownSeconds: 3,
  keepAwake: true,
  language: detectLanguage(),
};

// ============================================================================================
// Pocket — big expenses grouped by project, each expense in one category. Single currency (₾).
// ============================================================================================
export type ProjectStatus = 'active' | 'done';

export interface Project {
  id: string;
  name: string;
  notes: string;
  /** Planned total, in ₾. Undefined = no budget set. */
  budget?: number;
  /** Optional per-category limits, keyed by category id. */
  categoryBudgets: Record<string, number>;
  status: ProjectStatus;
  startDate: string; // YYYY-MM-DD
  createdAt: number;
  updatedAt: number;
}

export interface Category {
  id: string;
  name: string;
  color: string; // hex
  icon: CategoryIcon;
  order: number;
  createdAt: number;
}

export type CategoryIcon = 'box' | 'wrench' | 'sofa' | 'hammer' | 'tag' | 'truck' | 'bolt' | 'drop' | 'paint' | 'home' | 'doc' | 'cart' | 'heart' | 'gift' | 'car' | 'plane';
export const CATEGORY_ICONS: CategoryIcon[] = ['box', 'wrench', 'sofa', 'hammer', 'tag', 'truck', 'bolt', 'drop', 'paint', 'home', 'doc', 'cart', 'heart', 'gift', 'car', 'plane'];
export const CATEGORY_COLORS = ['#E39A1C', '#4C8BF5', '#B76DE0', '#2FAF6E', '#F0532D', '#E9B52A', '#1FA8A8', '#D9488A', '#7A6A52', '#9A978F'];

export interface Expense {
  id: string;
  projectId: string;
  categoryId: string;
  title: string;
  amount: number; // ₾
  date: string; // YYYY-MM-DD
  note: string;
  createdAt: number;
  updatedAt: number;
}

// ============================================================================================
// Family Tree — several trees; each tree has persons and "unions" (a couple, or a single parent)
// that own the children. Parent/child links always go through a union so layout is simple.
// ============================================================================================
export interface Tree {
  id: string;
  name: string;
  notes: string;
  /** Person the canvas centres on when opened (defaults to the first person). */
  rootPersonId?: string;
  createdAt: number;
  updatedAt: number;
}

export type Sex = 'm' | 'f' | 'u';

export interface Person {
  id: string;
  treeId: string;
  firstName: string;
  lastName: string;
  maidenName: string;
  sex: Sex;
  /** Partial ISO dates allowed: "1958", "1958-04" or "1958-04-12". Empty = unknown. */
  birthDate: string;
  deathDate: string;
  /** True when the person has died but the date is unknown. */
  deceased: boolean;
  birthPlace: string;
  notes: string;
  photoBlobId?: string;
  /** Manual canvas position; when unset the auto-layout decides. */
  pos?: { x: number; y: number };
  createdAt: number;
  updatedAt: number;
}

export type UnionStatus = 'married' | 'partners' | 'divorced' | 'separated' | 'widowed' | 'unknown';
export const UNION_STATUSES: UnionStatus[] = ['married', 'partners', 'divorced', 'separated', 'widowed', 'unknown'];

export interface Union {
  id: string;
  treeId: string;
  /** 0, 1 or 2 partner ids. 1 = single/unknown other parent, 0 = "unknown parents" placeholder. */
  partnerIds: string[];
  status: UnionStatus;
  startYear: string;
  endYear: string;
  /** Children in display order. */
  childIds: string[];
  createdAt: number;
  updatedAt: number;
}

// ============================================================================================
// Flags — the country list lives in src/data/countries.ts; only quiz results are stored.
// ============================================================================================
export type Continent = 'Africa' | 'Asia' | 'Europe' | 'North America' | 'South America' | 'Oceania';
export const CONTINENTS: Continent[] = ['Europe', 'Asia', 'Africa', 'North America', 'South America', 'Oceania'];
export type ContinentFilter = Continent | 'all';

export type QuizMode = 'flag' | 'country' | 'capital';
export const QUIZ_MODES: QuizMode[] = ['flag', 'country', 'capital'];
export const QUIZ_LENGTH = 10;

export interface QuizResult {
  id: string;
  mode: QuizMode;
  continent: ContinentFilter;
  score: number;
  total: number;
  /** country codes answered wrong (asked again first next time) */
  missed: string[];
  playedAt: number;
}

// ============================================================================================
// Notes — groups of free-form notes. A note body is plain text; lines that start with "[ ]" or
// "[x]" render as tappable checkboxes and URLs are detected at render time. Tags are free-form.
// ============================================================================================
export interface NoteGroup {
  id: string;
  name: string;
  color: string; // hex, from CATEGORY_COLORS
  icon: CategoryIcon;
  order: number;
  createdAt: number;
  updatedAt: number;
}

export interface Note {
  id: string;
  groupId: string;
  title: string;
  /** Plain text. Checklist lines: "[ ] buy milk" / "[x] done". */
  body: string;
  tags: string[];
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
}

// ============================================================================================
// Meds — medicine courses. A course is a sequence of phases; each phase lasts N days (0 = until
// stopped) and has dose slots at fixed times. Every taken/skipped dose is logged (one row per
// medication × date × slot). Alerts come from the phone's Calendar via .ics export.
// ============================================================================================
export type MedKind = 'medicine' | 'supplement';
export const MED_KINDS: MedKind[] = ['medicine', 'supplement'];

export type MedForm = 'tablet' | 'capsule' | 'drops' | 'ml' | 'sachet' | 'injection' | 'puff' | 'other';
export const MED_FORMS: MedForm[] = ['tablet', 'capsule', 'drops', 'ml', 'sachet', 'injection', 'puff', 'other'];

export type DoseHint = 'none' | 'beforeMeal' | 'afterMeal' | 'withFood' | 'emptyStomach' | 'beforeSleep' | 'onWaking' | 'plentyWater' | 'noDairy' | 'noAlcohol' | 'stayUpright';
export const DOSE_HINTS: DoseHint[] = ['none', 'beforeMeal', 'afterMeal', 'withFood', 'emptyStomach', 'beforeSleep', 'onWaking', 'plentyWater', 'noDairy', 'noAlcohol', 'stayUpright'];

export interface DoseSlot {
  id: string;
  time: string; // "HH:MM" local
  /** Number of units (tablets, ml, drops…) — free text so "1/2" or "2 puffs" work too. */
  amount: string;
  hint: DoseHint;
  /** "Take N minutes after <another medication>" — the Today list annotates the chain. */
  afterMedId?: string;
  gapMin?: number;
  note: string;
}

export interface Phase {
  id: string;
  /** Optional label ("Week 1", "Loading dose"). */
  label: string;
  /** Length in days; 0 = open-ended (only meaningful for the last phase). */
  days: number;
  slots: DoseSlot[];
}

export type MedStatus = 'active' | 'paused' | 'done';

export interface Medication {
  id: string;
  kind: MedKind;
  name: string;
  /** Strength per unit, free text: "500 mg", "5 mg/ml". */
  strength: string;
  form: MedForm;
  color: string;
  /** Who takes it — free text ("me", "Nino"); empty = me. */
  person: string;
  /** Why / prescribed by — free text. */
  notes: string;
  startDate: string; // YYYY-MM-DD, first day of phase 1
  /** 0 = Sunday … 6 = Saturday; empty = every day. */
  weekdays: number[];
  phases: Phase[];
  status: MedStatus;
  /** Optional stock (units left; decremented on every "taken"). */
  stock?: number;
  stockWarnAt?: number;
  createdAt: number;
  updatedAt: number;
}

export type DoseStatus = 'taken' | 'skipped';

export interface DoseLog {
  /** `${medId}_${date}_${slotId}` */
  id: string;
  medId: string;
  date: string; // YYYY-MM-DD
  slotId: string;
  status: DoseStatus;
  /** When it was marked. */
  at: number;
}

// ============================================================================================
// Lingua — language courses. Built-in course content ships as static JSON packs under
// public/lang/<packId>/ (words / sentences / grammar); the user's own additions, every course's
// settings and all learning progress live in IndexedDB (and therefore in the backup).
// ============================================================================================
export type LLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1';
export type LDirection = 't2s' | 's2t' | 'mix';

export interface LangSide { code: string; name: string; tts: string }

export interface LangCourse {
  id: string;
  title: string;
  target: LangSide;      // the language being learned
  source: LangSide;      // the language explanations/translations are in
  /** Built-in pack folder under public/lang/ ("ru-en"), absent for user-made courses. */
  pack?: string;
  goals: { active: number; passive: number };
  dailyNew: number;      // new words to learn per day
  sessionSize: number;   // cards per round
  direction: LDirection; // default card direction
  showBoth: boolean;     // cards: show both sides at once (else tap to flip)
  autoSpeak: boolean;    // read the target side aloud when a card appears
  rate: number;          // speech rate for the target language
  order: number;
  createdAt: number;
}

export interface LangItem {
  id: string;
  courseId: string;
  kind: 'word' | 'sentence' | 'grammar';
  /** LWord / LSentence / LGrammarUnit (see lib/lingua.ts) */
  data: unknown;
  createdAt: number;
}

/** One spaced-repetition card. key: "w:<wordId>:r" (recognise), "w:<wordId>:p" (produce),
 *  "s:<sentenceId>" (build), "sp:<sentenceId>" (say it), "gd:<unitId>#<n>" (grammar drill), "g:<unitId>" (unit done). */
export interface LangProgress {
  id: string;            // `${courseId}|${key}`
  courseId: string;
  key: string;
  state: 'learning' | 'review' | 'known' | 'suspended';
  ivl: number;           // interval in days (0 = again today)
  ease: number;
  reps: number;
  lapses: number;
  due: string;           // YYYY-MM-DD
  last: number;          // timestamp of last answer
  /** In the mistakes bank until answered right on a later day. */
  miss?: boolean;
  lw?: string;           // date of the last wrong answer
  score?: number;        // grammar units: best drill score %
  created?: string;      // date the card was first answered
}

export interface LangLog {
  id: string;            // `${courseId}|${date}`
  courseId: string;
  date: string;
  answers: number;
  correct: number;
  learned: number;       // new words learned
  sentences: number;
  drills: number;
  seconds: number;
}
